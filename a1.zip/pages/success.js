import { useEffect } from 'react';
import { useRouter } from 'next/router';

export default function SuccessRedirect() {
  const router = useRouter();

  useEffect(() => {
    const userId = localStorage.getItem('user_id');
    if (userId) {
      router.replace(`/${userId}?success=true`);
    } else {
      router.replace('/');
    }
  }, []);

  return null;
}
