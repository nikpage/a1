// pages/[user_id].js

import { useState, useEffect } from 'react'
import AnalysisDisplay from '../components/AnalysisDisplay'

export default function UserPage({ user_id, parsedCvText, pastedJobText }) {
  const [analysis, setAnalysis] = useState(null)

  useEffect(() => {
    // Fetch analysis using user_id only, no hashText needed
    const fetchAnalysis = async () => {
      try {
        const res = await fetch('/api/get-analysis', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ user_id })
        })

        const data = await res.json()
        setAnalysis(data.analysis)
      } catch (err) {
        setAnalysis('Failed to load analysis')
      }
    }
    if (user_id) fetchAnalysis()
  }, [user_id])

  return (
    <div>
      <AnalysisDisplay analysisText={analysis} />
    </div>
  )
}
export async function getServerSideProps(context) {
  const { user_id } = context.params
  return {
    props: { user_id },
  }
}
