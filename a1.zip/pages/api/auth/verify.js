// pages/api/auth/verify.js
import { createClient } from '@supabase/supabase-js';
import crypto from 'crypto';
import redis from '../../../lib/redis';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  const { token } = req.query;
  console.log('✅ Verify API hit:', token);

  if (!token) {
    res.status(400).json({ error: 'missing-token' });
    return;
  }

  try {
    // Fetch latest token row
    const { data, error } = await supabase
      .from('magic_tokens')
      .select('*')
      .eq('token', token)
      .order('created_at', { ascending: false })
      .limit(1);

    if (error || !data || data.length === 0) {
      console.log('❌ Invalid token or error:', error);
      res.redirect(302, '/?error=login-failed');
      return;
    }

    const tokenData = data[0];
    console.log('✅ Token fetched:', tokenData);

    // Validate expiry / used
    if (tokenData.used || new Date(tokenData.expires_at) <= new Date()) {
      console.log('❌ Token expired or used');
      res.redirect(302, '/?error=login-failed');
      return;
    }

    // Create session
    const sessionToken = crypto.randomBytes(32).toString('hex');
    await redis.set(
      `session:${sessionToken}`,
      JSON.stringify({ email: tokenData.email, user_id: tokenData.user_id }),
      'EX',
      30 * 24 * 60 * 60
    );
    console.log('✅ Session created:', sessionToken);

    // Mark token used instead of deleting
    await supabase
      .from('magic_tokens')
      .update({ used: true })
      .eq('id', tokenData.id);

    // Set cookie
    res.setHeader('Set-Cookie', [
      `auth-token=${sessionToken}; HttpOnly; Path=/; Max-Age=${
        30 * 24 * 60 * 60
      }; SameSite=None; Secure`
    ]);

    console.log('✅ Cookie set, redirecting');
    res.redirect(302, `/${tokenData.user_id}`);
  } catch (err) {
    console.error('Verify error:', err);
    res.redirect(302, '/?error=login-failed');
  }
}
