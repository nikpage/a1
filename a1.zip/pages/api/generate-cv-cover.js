// pages/api/generate-cv-cover.js

import { getCVByUserId } from '@/utils/database';
import { generateDocuments } from '@/utils/openai';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { user_id, analysis, tone = 'Formal', type = 'both' } = req.body;

  if (!user_id || !analysis || !type) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  try {
    const cvRecord = await getCVByUserId(user_id);
    if (!cvRecord || !cvRecord.cv_data) {
      return res.status(404).json({ error: 'CV not found for user' });
    }

    const generated = await generateDocuments({
      cv: cvRecord.cv_data,
      analysis,
      tone,
      type,
    });

    return res.status(200).json({ docs: generated });
  } catch (err) {
    console.error('Generation error:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
}
