// path: components/TabbedViewer.js
import { useState, useEffect } from 'react';
import { supabase } from '../utils/database';
import ReactMarkdown from 'react-markdown';
import CV_Cover_Display from './CV-Cover-Display';
import DocumentDownloadButtons from './DocumentDownloadButtons';
import DownloadTokenPanel from './DownloadTokenPanel';
import ThankYouModal from './ThankYouModal';

export default function TabbedViewer({ user_id, analysisText }) {
  const [activeTab, setActiveTab] = useState('analysis');
  const [docs, setDocs] = useState({ cv: null, cover: null });
  const [showBuilder, setShowBuilder] = useState(false);
  const [showBuyPanel, setShowBuyPanel] = useState(false);
  const [showThankYou, setShowThankYou] = useState(false);

  useEffect(() => {
    const fetchDocs = async () => {
      if (!user_id) return;

      const { data, error } = await supabase
        .from('gen_data')
        .select('type, content')
        .eq('user_id', user_id)
        .in('type', ['cv', 'cover'])
        .order('created_at', { ascending: false });

      if (!error && data) {
        const result = { cv: null, cover: null };
        for (const row of data) {
          if (row.type === 'cv' && !result.cv) result.cv = row.content;
          if (row.type === 'cover' && !result.cover) result.cover = row.content;
        }
        setDocs(result);
      }
    };

    fetchDocs();
  }, [user_id, activeTab]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const success = params.get('success');
    if (success === 'true') {
      setShowThankYou(true);
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  const tabs = [
    { id: 'analysis', label: 'Analysis' },
    { id: 'cv', label: 'CV' },
    { id: 'cover', label: 'Cover Letter' }
  ];

  return (
    <div className="doc-viewer" style={{
      background: "#fff",
      borderRadius: "12px",
      boxShadow: "0 1px 6px rgba(0,0,0,0.06)",
      padding: "2.5rem",
      margin: "2rem auto",
      maxWidth: "980px"
    }}>
      <div className="tabs-bar">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`tab-btn${activeTab === tab.id ? ' active' : ''}`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div>
        {activeTab === 'analysis' && (
          <div>
            {analysisText ? (
              <>
                <div className="doc-viewer">
                  <ReactMarkdown>{analysisText}</ReactMarkdown>
                </div>

                {!showBuilder && (
                  <div style={{ textAlign: 'center', marginTop: '2rem' }}>
                    <button
                      onClick={() => setShowBuilder(true)}
                      className="action-btn"
                    >
                      Write Now!
                    </button>
                  </div>
                )}

                {showBuilder && (
                  <CV_Cover_Display user_id={user_id} analysis={analysisText} />
                )}
              </>
            ) : (
              <p>No analysis available</p>
            )}
          </div>
        )}

        {activeTab === 'cv' && (
          <div>
            {docs.cv ? (
              <>
                <div className="doc-viewer">
                  <ReactMarkdown>{docs.cv}</ReactMarkdown>
                </div>
                <DocumentDownloadButtons
                  user_id={user_id}
                  analysisText={analysisText}
                  cvText={docs.cv}
                  coverText={docs.cover}
                  onTokenFail={() => setShowBuyPanel(true)}
                  activeTab={activeTab}
                />
              </>
            ) : (
              <CV_Cover_Display user_id={user_id} analysis={analysisText} defaultType="cv" />
            )}
          </div>
        )}

        {activeTab === 'cover' && (
          <div>
            {docs.cover ? (
              <>
                <div className="doc-viewer">
                  <ReactMarkdown>{docs.cover}</ReactMarkdown>
                </div>
                <DocumentDownloadButtons
                  user_id={user_id}
                  analysisText={analysisText}
                  cvText={docs.cv}
                  coverText={docs.cover}
                  onTokenFail={() => setShowBuyPanel(true)}
                  activeTab={activeTab}
                />
              </>
            ) : (
              <CV_Cover_Display user_id={user_id} analysis={analysisText} defaultType="cover" />
            )}
          </div>
        )}
      </div>

      {showBuyPanel && (
        <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-[1000]">
          <DownloadTokenPanel onClose={() => setShowBuyPanel(false)} user_id={user_id} />
        </div>
      )}

      {showThankYou && (
        <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-[1000]">
          <ThankYouModal onClose={() => setShowThankYou(false)} />
        </div>
      )}
    </div>
  );
}
