// path: components/CV-Cover-Display.js

import { useState, useEffect } from 'react';
import DownloadTokenPanel from './DownloadTokenPanel';
import { supabase } from '../utils/database';

export default function CV_Cover_Display({ user_id, analysis }) {
  const [tone, setTone] = useState('Formal');
  const [docTypes, setDocTypes] = useState({ cv: false, cover: false });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [docs, setDocs] = useState(null);
  const [showBuyPanel, setShowBuyPanel] = useState(false);

  useEffect(() => {
    const loadDocs = async () => {
      if (!user_id || !analysis || !tone || !analysis.analysis_id) return;
      const { source_cv_id, analysis_id } = analysis;

      const { data, error } = await supabase
        .from('gen_data')
        .select('type, content')
        .eq('user_id', user_id)
        .eq('source_cv_id', source_cv_id)
        .eq('tone', tone)
        .eq('analysis_id', analysis_id)
        .in('type', ['cv', 'cover']);

      if (!error && data) {
        const result = { cv: null, cover: null };
        for (const row of data) {
          if (row.type === 'cv') result.cv = row.content;
          if (row.type === 'cover') result.cover = row.content;
        }
        setDocs(result);
      }
    };

    loadDocs();
  }, [user_id, analysis, tone]);

  const handleDownload = async (type, content) => {
    const res = await fetch('/api/download-token-check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id, type, content }),
    });

    if (res.status === 402) {
      setShowBuyPanel(true);
      return;
    }

    if (!res.ok) {
      alert('Download failed');
      return;
    }

    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = res.headers.get('Content-Disposition')?.match(/filename="(.+?)"/)?.[1] || 'download.docx';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const toggleDocType = (type) => {
    setDocTypes(prev => ({ ...prev, [type]: !prev[type] }));
  };

  const canGenerate = docTypes.cv || docTypes.cover;

  const handleGenerate = async () => {
    if (!canGenerate || !analysis) return;
    setLoading(true);
    setError(null);
    setDocs(null);
    try {
      const res = await fetch('/api/generate-cv-cover', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id,
          analysis,
          tone,
          type: docTypes.cv && docTypes.cover ? 'both' : docTypes.cv ? 'cv' : 'cover',
        }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        setError(data.error || 'Generation failed');
      } else {
        setDocs({ cv: data.cv, cover: data.cover });
      }
    } catch (err) {
      setError('Error: ' + err.message);
    }
    setLoading(false);
  };

  useEffect(() => {
    const search = window.location.search;
    if (search.includes('success=true')) {
      setShowBuyPanel(false);
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  return (
    <div className="doc-viewer">
      <h3>🎯 Choose Tone</h3>
      <div className="tabs-bar" style={{ justifyContent: 'center', marginBottom: '2rem' }}>
        {['Formal', 'Friendly', 'Enthusiastic', 'Cocky'].map((t) => (
          <button
            key={t}
            onClick={() => setTone(t)}
            className={`tab-btn ${tone === t ? 'active' : ''}`}
          >
            {t}
          </button>
        ))}
      </div>

      <h3>📄 Select Document Type</h3>
      <div className="tabs-bar" style={{ justifyContent: 'center', marginBottom: '2rem' }}>
        <label><input type="checkbox" checked={docTypes.cv} onChange={() => toggleDocType('cv')} /> CV</label>
        <label><input type="checkbox" checked={docTypes.cover} onChange={() => toggleDocType('cover')} /> Cover Letter</label>
      </div>

      <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
        <button
          onClick={handleGenerate}
          disabled={!canGenerate || loading}
          className="action-btn"
          style={{ opacity: canGenerate && !loading ? 1 : 0.5, cursor: canGenerate && !loading ? 'pointer' : 'not-allowed' }}
        >
          {loading ? 'Generating…' : 'Generate'}
        </button>
        {error && <div style={{ color: 'red', marginTop: 16 }}>{error}</div>}
      </div>

      {showBuyPanel && (
        <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-[1000]">
          <DownloadTokenPanel onClose={() => setShowBuyPanel(false)} user_id={user_id} />
        </div>
      )}

      {docs && (
        <div style={{ marginTop: 32 }}>
          {docs.cv && (
            <>
              <h3>CV</h3>
              <pre>{docs.cv}</pre>
              <button onClick={() => handleDownload('cv', docs.cv)} className="download-btn">
                Download CV
              </button>
            </>
          )}
          {docs.cover && (
            <>
              <h3>Cover Letter</h3>
              <pre>{docs.cover}</pre>
              <button onClick={() => handleDownload('cover', docs.cover)} className="download-btn">
                Download Cover Letter
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}
