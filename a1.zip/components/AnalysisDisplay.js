// components/AnalysisDisplay.js
export default function AnalysisDisplay({ analysisText }) {
  if (!analysisText || typeof analysisText !== 'string') return null

  const safeHTML = analysisText.startsWith('<')
    ? analysisText
    : `<pre>${analysisText}</pre>`

  return (
    <div className="formatted-analysis" dangerouslySetInnerHTML={{ __html: safeHTML }} />
  )
}
