// path: components/AnalysisDisplay.js
export default function AnalysisDisplay({ analysis }) {
  const cleanedContext = analysis?.context
    ?.replace(/^#+\s?/gm, '')
    ?.replace(/\n{2,}/g, '\n');

  return (
    <div className="doc-viewer">
      <section style={{ marginBottom: "2rem" }}>
        <h2 style={{ fontSize: "1.1rem", fontWeight: "600", borderBottom: "1px solid #e6eaf0", paddingBottom: "0.4rem", marginBottom: "0.8rem" }}>
          Extracted CV Metadata
        </h2>
        <ul style={{ paddingLeft: "1rem", lineHeight: "1.8" }}>
          <li><strong>Full Name:</strong> {analysis.fullName}</li>
          <li><strong>Country:</strong> {analysis.country}</li>
          <li><strong>Industry:</strong> {analysis.industry}</li>
          <li><strong>Seniority:</strong> {analysis.seniority}</li>
        </ul>
      </section>

      <section style={{ marginBottom: "2rem" }}>
        <h2 style={{ fontSize: "1.1rem", fontWeight: "600", borderBottom: "1px solid #e6eaf0", paddingBottom: "0.4rem", marginBottom: "0.8rem" }}>
          At a Glance
        </h2>
        <p>{analysis.summary}</p>
        <ul style={{ listStyleType: "decimal", paddingLeft: "1.2rem", marginTop: "0.8rem", lineHeight: "1.8" }}>
          {analysis.targetedLetterPoints.map((point, i) => (
            <li key={i}>{point}</li>
          ))}
        </ul>
      </section>

      <section style={{ marginBottom: "2rem" }}>
        <h2 style={{ fontSize: "1.1rem", fontWeight: "600", borderBottom: "1px solid #e6eaf0", paddingBottom: "0.4rem", marginBottom: "0.8rem" }}>
          Step 1: Scoring
        </h2>
        <p><strong>Overall Score:</strong> {analysis.score}</p>
        <p><strong>ATS Compatibility:</strong> {analysis.ats}</p>
      </section>

      <section style={{ marginBottom: "2rem" }}>
        <h2 style={{ fontSize: "1.1rem", fontWeight: "600", borderBottom: "1px solid #e6eaf0", paddingBottom: "0.4rem", marginBottom: "0.8rem" }}>
          Step 2: Scenario Tags
        </h2>
        <p>{analysis.scenarioTags}</p>
      </section>

      <section>
        <h2 style={{ fontSize: "1.1rem", fontWeight: "600", borderBottom: "1px solid #e6eaf0", paddingBottom: "0.4rem", marginBottom: "0.8rem" }}>
          Step 3: Context Analysis
        </h2>
        <p>{cleanedContext}</p>
      </section>
    </div>
  );
}
