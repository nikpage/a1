// path: components/DocumentDownloadButtons.js
import { supabase } from '../utils/database';

export default function DocumentDownloadButtons({
  user_id,
  cvText,
  coverText,
  activeTab,
  onTokenFail,
}) {
  const handleDownload = async () => {
    const type = activeTab === 'cv' ? 'cv' : 'cover';
    const content = type === 'cv' ? cvText : coverText;
    if (!content) return;

    const { data: profile, error } = await supabase
      .from('profiles')
      .select('tokens')
      .eq('id', user_id)
      .single();

    if (error || !profile || profile.tokens <= 0) {
      onTokenFail?.();
      return;
    }

    await supabase
      .from('profiles')
      .update({ tokens: profile.tokens - 1 })
      .eq('id', user_id);

    const blob = new Blob([content], {
      type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${type}-${user_id}.docx`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '2rem' }}>
      <button className="download-btn" onClick={handleDownload}>
        Download {activeTab === 'cv' ? 'CV' : 'Cover Letter'}
      </button>
    </div>
  );
}
