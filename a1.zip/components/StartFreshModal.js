import React, { useState, useEffect } from 'react'
import StartFreshSelector from './StartFreshSelector'
import StartFreshDbModal from './StartFreshDbModal'
import StartFreshUploadModal from './StartFreshUploadModal'

export default function StartFreshModal({
  user_id,
  onSubmit,
  handleCvUploadFromModal,
  onStartFresh,
  onClose,
}) {
  const [step, setStep] = useState(1)
  const [cvOptions, setCvOptions] = useState([])
  const [loading, setLoading] = useState(false)
  const [selectedCvId, setSelectedCvId] = useState('')
  const [jobDescription, setJobDescription] = useState('')

  const fetchCVs = async () => {
    setLoading(true)
    try {
      const res = await fetch(`/api/get-cvs?user_id=${user_id}`)
      const data = await res.json()
      if (Array.isArray(data)) {
        const options = data.map(cv => ({
          id: cv.id,
          name: cv.filename && cv.filename.trim() !== ''
            ? cv.filename
            : new Date(cv.created_at).toLocaleString('en-GB', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false
              }),
          uploadedAt: cv.created_at
        }))
        setCvOptions(options)
        if (options.length > 0) {
          setSelectedCvId(options[0].id)
        }
      }
    } catch (err) {
      console.error('Error fetching CVs', err)
      setCvOptions([])
    }
    setLoading(false)
  }


  useEffect(() => {
    if (step === 2) fetchCVs()
  }, [step])

  const handleSubmit = (cvId, jobDesc) => {
    window.dispatchEvent(new CustomEvent('new-analysis', {
      detail: { analysis: { cv_id: cvId, job_description: jobDesc } }
    }))
    localStorage.removeItem('cvVersions')
    localStorage.removeItem('coverVersions')
    localStorage.removeItem('analysisText')
    localStorage.setItem('shouldFetchFromDB', 'false')
    onStartFresh()
    onClose()
  }

  return (
    <>
      {step === 1 && (
        <StartFreshSelector
          onChooseDb={() => setStep(2)}
          onChooseUpload={() => setStep(3)}
          onClose={() => { setStep(1); onClose() }}
        />
      )}

      {step === 2 && (
        <StartFreshDbModal
          user_id={user_id}
          cvOptions={cvOptions}
          selectedCvId={selectedCvId}
          setSelectedCvId={setSelectedCvId}
          jobDescription={jobDescription}
          setJobDescription={setJobDescription}
          loading={loading}
          onSubmit={handleSubmit}
          onStartFresh={onStartFresh}
          onBack={() => setStep(1)}
          onClose={() => { setStep(1); onClose() }}
        />
      )}

      {step === 3 && (
        <StartFreshUploadModal
          handleCvUploadFromModal={handleCvUploadFromModal}
          jobDescription={jobDescription}
          setJobDescription={setJobDescription}
          loading={loading}
          onBack={() => setStep(1)}
          onClose={() => { setStep(1); onClose() }}
        />
      )}
    </>
  )
}
