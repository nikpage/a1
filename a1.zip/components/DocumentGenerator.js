//components/DocumentGenerator.js
import { useState } from 'react';

export default function DocumentGenerator({ user_id, analysis }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [docs, setDocs] = useState(null);

  const handleGenerate = async () => {
    if (!analysis) return;
    setLoading(true);
    setError(null);
    setDocs(null);
    try {
      const res = await fetch('/api/generate-cv-cover', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id,
          analysis,
          tone: 'Formal',
          type: 'both',
        }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        setError(data.error || 'Generation failed');
        setLoading(false);
        return;
      }
      setDocs(data.docs);
    } catch (err) {
      setError('Error: ' + err.message);
    }
    setLoading(false);
  };

  return (
    <div style={{ textAlign: 'center', marginTop: 24 }}>
      <button
        onClick={handleGenerate}
        disabled={loading || !analysis}
        style={{
          padding: '0.5rem 1.5rem',
          background: loading || !analysis ? '#bbb' : '#224488',
          color: '#fff',
          border: 'none',
          borderRadius: 6,
          fontWeight: 700,
          cursor: loading || !analysis ? 'not-allowed' : 'pointer',
        }}
      >
        {loading ? 'Generating…' : 'Generate'}
      </button>
      {error && <div style={{ color: 'red', marginTop: 16 }}>{error}</div>}
      {docs && (
        <div style={{ marginTop: 32, textAlign: 'left' }}>
          {docs.cv && (
            <>
              <h3>CV</h3>
              <pre style={{ background: '#f8f8fa', padding: 12, borderRadius: 8 }}>
                {docs.cv}
              </pre>
            </>
          )}
          {docs.cover && (
            <>
              <h3>Cover Letter</h3>
              <pre style={{ background: '#f8f8fa', padding: 12, borderRadius: 8 }}>
                {docs.cover}
              </pre>
            </>
          )}
        </div>
      )}
    </div>
  );
}
